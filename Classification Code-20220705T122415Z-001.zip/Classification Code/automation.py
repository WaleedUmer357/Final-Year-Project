import openpyxl as xl
wb=xl.load_workbook('ali_fist.xlsx')
sheet=wb['Sheet1']



for i in range(1,5):
    sheet.cell(i,4).value=1
    


'''wb.save('sheet_openpy.xlsx')'''
wb.save('ali_fist.xlsx')